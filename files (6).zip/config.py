import os
from dotenv import load_dotenv

load_dotenv()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")
DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
DATABASE_URL = os.getenv("DATABASE_URL") or "postgresql+asyncpg://barberuser:barberpass@db:5432/barberbot"
ADMIN_TG_ID = int(os.getenv("ADMIN_TG_ID", "0"))