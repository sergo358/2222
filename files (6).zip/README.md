# BarberBot

## Быстрый старт

1. Склонируй репозиторий:
   ```bash
   git clone https://github.com/sergo358/2222.git
   cd 2222
   ```

2. Скопируй `.env.example` в `.env`, впиши свои ключи.

3. Запусти проект:
   ```bash
   docker-compose up --build
   ```

4. Проверь работу:
   - Бот: напиши своему Telegram-боту `/start`
   - Админ-панель: http://localhost:8000/docs (Swagger)

5. Остановить проект:
   ```bash
   docker-compose down
   ```

## Автоматическая загрузка изменений

1. Сделай скрипт исполняемым:
   ```bash
   chmod +x push.sh
   ```

2. Запусти:
   ```bash
   ./push.sh "Комментарий к коммиту"
   ```

---

## Структура проекта

- Основные файлы: `handlers.py`, `main.py`, `models.py`, `admin_api.py`, `init_db.py` и др.
- Инфраструктура: `Dockerfile`, `docker-compose.yml`, `.env.example`
- CI/CD: `.github/workflows/ci.yml`
- Скрипт автозагрузки: `push.sh`
- Тесты: `tests/test_health.py`

---

## CI/CD

- После пуша смотри статус на https://github.com/sergo358/2222/actions

---

## Если нужна помощь

Пиши Issues или Pull Requests!