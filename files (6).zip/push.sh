#!/bin/bash
# Скрипт для полной автоматизации: запуск, тесты и пуш в одну команду

set -e

# Запуск и сборка контейнеров
docker-compose build
docker-compose up -d

# (Необязательно) Запустить тесты внутри контейнера
if docker-compose exec bot pytest; then
  echo "Тесты успешно пройдены"
else
  echo "Ошибка тестов! Пуш отменён"
  exit 1
fi

# Готовим git-пуш
git add .
git commit -m "${1:-Автоматический коммит}"
git push origin main

echo "✅ Все готово и отправлено в репозиторий!"