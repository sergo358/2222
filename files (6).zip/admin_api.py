from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from models import Client, Salon, Appointment
from main import async_session
from config import ADMIN_TG_ID

router = APIRouter(prefix="/admin", tags=["admin"])

async def get_db():
    async with async_session() as session:
        yield session

async def check_admin(request: Request):
    tg_id = request.headers.get("X-Tg-Admin-Id")
    if not tg_id or int(tg_id) != ADMIN_TG_ID:
        raise HTTPException(status_code=403, detail="Not admin")

@router.get("/appointments")
async def list_appointments(request: Request, db: AsyncSession = Depends(get_db)):
    await check_admin(request)
    result = await db.execute(select(Appointment).order_by(Appointment.datetime.desc()))
    appointments = result.scalars().all()
    return [
        {
            "id": a.id,
            "client": a.client.name if a.client else None,
            "salon": a.salon.name if a.salon else None,
            "datetime": a.datetime,
            "status": a.status
        }
        for a in appointments
    ]

@router.get("/clients")
async def list_clients(request: Request, db: AsyncSession = Depends(get_db)):
    await check_admin(request)
    result = await db.execute(select(Client))
    clients = result.scalars().all()
    return [{"id": c.id, "name": c.name, "tg_id": c.tg_id, "phone": c.phone} for c in clients]

@router.get("/salons")
async def list_salons(request: Request, db: AsyncSession = Depends(get_db)):
    await check_admin(request)
    result = await db.execute(select(Salon))
    salons = result.scalars().all()
    return [{"id": s.id, "name": s.name, "address": s.address} for s in salons]