from sqlalchemy import Column, Integer, String, DateTime, ForeignKey
from sqlalchemy.orm import declarative_base, relationship
import datetime

Base = declarative_base()

class Salon(Base):
    __tablename__ = "salons"
    id = Column(Integer, primary_key=True)
    name = Column(String, nullable=False)
    address = Column(String, nullable=False)

class Client(Base):
    __tablename__ = "clients"
    id = Column(Integer, primary_key=True)
    tg_id = Column(String, unique=True)
    name = Column(String)
    phone = Column(String, nullable=True)

class Appointment(Base):
    __tablename__ = "appointments"
    id = Column(Integer, primary_key=True)
    client_id = Column(Integer, ForeignKey('clients.id'))
    salon_id = Column(Integer, ForeignKey('salons.id'))
    datetime = Column(DateTime, nullable=False)
    status = Column(String, default="pending")
    client = relationship("Client")
    salon = relationship("Salon")

class UserSession(Base):
    __tablename__ = "user_sessions"
    id = Column(Integer, primary_key=True)
    tg_id = Column(String, unique=True)
    stage = Column(String, default="start")
    name = Column(String, nullable=True)
    salon_id = Column(Integer, nullable=True)
    selected_date = Column(String, nullable=True)  # YYYY-MM-DD
    selected_time = Column(String, nullable=True)  # HH:MM