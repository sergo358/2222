import requests
from config import DEEPSEEK_API_KEY

API_URL = "https://api.deepseek.com/v1/chat/completions"

def ask_deepseek(prompt, chat_history=None):
    headers = {
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}",
        "Content-Type": "application/json"
    }
    payload = {
        "model": "deepseek-chat",
        "messages": chat_history or [{"role":"user","content":prompt}],
        "temperature": 0.7,
        "max_tokens": 200
    }
    try:
        response = requests.post(API_URL, json=payload, headers=headers, timeout=10)
        response.raise_for_status()
        return response.json()["choices"][0]["message"]["content"]
    except Exception:
        return "Извините, временно не могу обработать запрос. Попробуйте позже."