def process_payment(client_id, amount):
    # Заглушка для оплаты — всегда успех
    return {
        "status": "success",
        "transaction_id": "stub-transaction-123456"
    }