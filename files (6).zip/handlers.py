from aiogram import Router, types, F
from aiogram.filters import CommandStart
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from models import Client, Salon, Appointment, UserSession
from deepseek_api import ask_deepseek
import datetime
from config import ADMIN_TG_ID

router = Router()

async def get_or_create_user_session(session, tg_id):
    result = await session.execute(select(UserSession).where(UserSession.tg_id == str(tg_id)))
    user_session = result.scalar_one_or_none()
    if not user_session:
        user_session = UserSession(tg_id=str(tg_id), stage="start")
        session.add(user_session)
        await session.commit()
    return user_session

def get_next_7_days():
    today = datetime.date.today()
    return [(today + datetime.timedelta(days=i)).strftime("%Y-%m-%d") for i in range(7)]

def get_time_slots():
    return [f"{h:02d}:00" for h in range(10, 19)]

@router.message(CommandStart())
async def start_handler(message: types.Message, session: AsyncSession):
    user_session = await get_or_create_user_session(session, message.from_user.id)
    user_session.stage = "start"
    await session.commit()
    await message.answer("Привет! Я помогу тебе записаться в парикмахерскую. Как тебя зовут?")

@router.message(commands=["admin"])
async def admin_panel(message: types.Message):
    if message.from_user.id != ADMIN_TG_ID:
        await message.answer("У вас нет доступа к админ-панели.")
        return
    await message.answer("Добро пожаловать в админ-панель!")

@router.message(F.text)
async def main_dialog(message: types.Message, session: AsyncSession):
    user_session = await get_or_create_user_session(session, message.from_user.id)

    if user_session.stage == "start":
        name = message.text.strip()
        user_session.name = name
        user_session.stage = "got_name"
        client = await session.scalar(select(Client).where(Client.tg_id == str(message.from_user.id)))
        if not client:
            client = Client(tg_id=str(message.from_user.id), name=name)
            session.add(client)
        else:
            client.name = name
        await session.commit()
        salons = (await session.execute(select(Salon))).scalars().all()
        kb = [
            [types.KeyboardButton(text=f"{salon.name} ({salon.address})")]
            for salon in salons
        ]
        reply_markup = types.ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)
        await message.answer(f"Приятно познакомиться, {name}! В какую парикмахерскую ты хочешь записаться?", reply_markup=reply_markup)
        return

    if user_session.stage == "got_name":
        salons = (await session.execute(select(Salon))).scalars().all()
        salon_map = {f"{salon.name} ({salon.address})": salon.id for salon in salons}
        chosen = message.text.strip()
        if chosen not in salon_map:
            await message.answer("Пожалуйста, выберите салон из списка.")
            return
        user_session.salon_id = salon_map[chosen]
        user_session.stage = "got_salon"
        await session.commit()
        days = get_next_7_days()
        kb = [[types.KeyboardButton(text=day)] for day in days]
        reply_markup = types.ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)
        await message.answer("Выберите дату:", reply_markup=reply_markup)
        return

    if user_session.stage == "got_salon":
        try:
            datetime.datetime.strptime(message.text.strip(), "%Y-%m-%d")
        except Exception:
            await message.answer("Пожалуйста, выберите дату из кнопок.")
            return
        user_session.selected_date = message.text.strip()
        user_session.stage = "got_date"
        await session.commit()
        slots = get_time_slots()
        kb = [[types.KeyboardButton(text=slot)] for slot in slots]
        reply_markup = types.ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)
        await message.answer("Выберите время:", reply_markup=reply_markup)
        return

    if user_session.stage == "got_date":
        if message.text.strip() not in get_time_slots():
            await message.answer("Пожалуйста, выберите время из кнопок.")
            return
        user_session.selected_time = message.text.strip()
        user_session.stage = "got_time"
        await session.commit()
        salon = await session.scalar(select(Salon).where(Salon.id == user_session.salon_id))
        prompt = (
            f"Пользователь {user_session.name} хочет записаться в {salon.name} "
            f"на {user_session.selected_date} в {user_session.selected_time}. "
            "Сформулируй дружелюбное подтверждение и спроси, всё ли верно."
        )
        llm_answer = ask_deepseek(prompt)
        await message.answer(llm_answer)
        return

    if user_session.stage == "got_time":
        if "да" in message.text.lower():
            client = await session.scalar(select(Client).where(Client.tg_id == str(message.from_user.id)))
            salon = await session.scalar(select(Salon).where(Salon.id == user_session.salon_id))
            dt = datetime.datetime.strptime(
                f"{user_session.selected_date} {user_session.selected_time}", "%Y-%m-%d %H:%M"
            )
            appointment = Appointment(client_id=client.id, salon_id=salon.id, datetime=dt)
            session.add(appointment)
            user_session.stage = "confirmed"
            await session.commit()
            prompt = (
                f"Пользователь {user_session.name} записан в {salon.name} ({salon.address}) на "
                f"{user_session.selected_date} в {user_session.selected_time}. Скажи спасибо и напомни прийти вовремя."
            )
            llm_answer = ask_deepseek(prompt)
            await message.answer(llm_answer)
        else:
            user_session.stage = "got_salon"
            await session.commit()
            await message.answer("Давайте выберем дату снова. Вот доступные даты:")
            days = get_next_7_days()
            kb = [[types.KeyboardButton(text=day)] for day in days]
            reply_markup = types.ReplyKeyboardMarkup(keyboard=kb, resize_keyboard=True)
            await message.answer("Выберите дату:", reply_markup=reply_markup)
        return

    if user_session.stage == "confirmed":
        await message.answer("Вы уже записаны! Если хотите записаться ещё раз — напишите /start.")