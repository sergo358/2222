import asyncio
from sqlalchemy.ext.asyncio import create_async_engine
from config import DATABASE_URL
from models import Base, Salon

SALONS = [
    {"name": "Style House", "address": "ул. Пушкина, 15"},
    {"name": "Elite Hair", "address": "пр. Ленина, 42"},
]

async def init_models():
    engine = create_async_engine(DATABASE_URL, echo=True)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
        result = await conn.execute(Salon.__table__.select())
        if not result.fetchone():
            await conn.execute(Salon.__table__.insert(), SALONS)
        await conn.commit()
    await engine.dispose()

if __name__ == "__main__":
    asyncio.run(init_models())