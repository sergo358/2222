import asyncio
from aiogram import Bot, Dispatcher
from aiogram.fsm.storage.memory import MemoryStorage
from fastapi import FastAPI, Request
from handlers import router
from config import TELEGRAM_TOKEN, DATABASE_URL
from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession
from sqlalchemy.orm import sessionmaker
import uvicorn
from admin_api import router as admin_router

app = FastAPI()
app.include_router(admin_router)

bot = Bot(token=TELEGRAM_TOKEN)
dp = Dispatcher(storage=MemoryStorage())
dp.include_router(router)

engine = create_async_engine(DATABASE_URL, echo=True)
async_session = sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)

@dp.update.outer_middleware()
async def db_session_middleware(handler, event, data):
    async with async_session() as session:
        data["session"] = session
        return await handler(event, data)

@app.post("/webhook")
async def telegram_webhook(request: Request):
    update = await request.json()
    await dp.feed_update(bot, update)
    return {"ok": True}

if __name__ == "__main__":
    asyncio.run(dp.start_polling(bot, allowed_updates=dp.resolve_used_update_types()))