# Архитектурная схема проекта BarberBot

## Основные компоненты

```
+-------------------+      Telegram API     +-------------------+
|                   | <------------------> |                   |
|   Telegram User   |                      |     BarberBot     |
|                   |                      | (aiogram/FastAPI) |
+-------------------+                      +-------------------+
                                                |    ▲
                                                |    |
                                                ▼    |
                                           +-----------------+
                                           |   PostgreSQL    |
                                           +-----------------+
                                                |
                                                ▼
                                           +----------------+
                                           |  DeepSeek API  |
                                           +----------------+

     Админ-панель (REST)  <------>  FastAPI  <------>  PostgreSQL
```

## Описание:
- Пользователь пишет боту в Telegram
- BarberBot (Python, aiogram, FastAPI) обрабатывает сообщения, хранит данные в PostgreSQL, интегрируется с DeepSeek для генерации текстов
- Админ-панель через REST API, защищённую по Telegram ID, даёт доступ к клиентам, салонам, бронированиям

## Инфраструктура:
- Docker Compose orchestrates:
    - service: bot (BarberBot)
    - service: db (PostgreSQL)